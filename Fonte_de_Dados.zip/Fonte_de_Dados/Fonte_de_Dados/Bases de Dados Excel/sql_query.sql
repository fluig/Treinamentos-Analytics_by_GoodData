﻿/*
Desenvolvidor por: Rodrigo Becker
Data: 23/02/2018
fluig Academy
*/

/*
Query utilizado para alterar os dados importados do excel para o banco de dados
*/

--Script de atualização do campo data na tabela dados
Update Dados$
Set Data = replace(Data, '2014', '2017');
select data from Dados$
-- Script de atualização do campo data na tabela Metas
Update Meta$
Set Data = replace(Data, '2014', '2017');
select data from Meta$

--Script de alteração do tipo da coluna das tabelas de nvarchar para varchar
ALTER TABLE Meta$ alter column Vendedor VARCHAR(100)
ALTER TABLE Meta$ alter column Data VARCHAR(100) 
ALTER TABLE Produto$ alter column Produto VARCHAR(100) 
ALTER TABLE Produto$ alter column Marca VARCHAR(100) 
ALTER TABLE Produto$ alter column Grupo VARCHAR(100) 
ALTER TABLE Produto$ alter column Subgrupo VARCHAR(100) 
ALTER TABLE Vendas$ alter column Vendedor VARCHAR(100) 
ALTER TABLE Vendas$ alter column Unidade VARCHAR(100) 
ALTER TABLE Vendas$ alter column UF VARCHAR(100) 
ALTER TABLE Vendas$ alter column Região VARCHAR(100) 
ALTER TABLE Vendas$ alter column Empresarial VARCHAR(100) 
ALTER TABLE Vendas$ alter column UF VARCHAR(100) 
ALTER TABLE Dados$ alter column Vendedor VARCHAR(100) 
ALTER TABLE Dados$ alter column Unidade VARCHAR(100) 
ALTER TABLE Dados$ alter column UF VARCHAR(100) 
ALTER TABLE Dados$ alter column Região VARCHAR(100) 
ALTER TABLE Dados$ alter column Produto VARCHAR(100) 
ALTER TABLE Dados$ alter column Marca VARCHAR(100) 
ALTER TABLE Dados$ alter column Grupo VARCHAR(100) 
ALTER TABLE Dados$ alter column Subgrupo VARCHAR(100) 
ALTER TABLE Dados$ alter column Data VARCHAR(100) 
ALTER TABLE Dados$ alter column Empresarial VARCHAR(100) 
ALTER TABLE Dados$ alter column AtacadoVarejo VARCHAR(100) 

